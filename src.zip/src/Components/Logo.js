import React from "react"

function Logo() {
    return(
        <div className="intro">
            <a href="#" className="intro--logo"><img src="../images/SomberSpirit.png" />Somber Spirit</a>
        </div>
    )
}

export default Logo;