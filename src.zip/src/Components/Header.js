import React from "react"

function Header() {
    return(
        <div className="header">
            <nav className="nav">
                <ul className="nav--pages">
                    <li><a href="#Min/Max">Min/Max</a></li>
                    <li><a href="#PriceCheck">Price Check</a></li>
                    <li><a href="#CraftingHelp">Crafting Help</a></li>
                </ul>
            </nav>
        </div>
    )
}

export default Header;