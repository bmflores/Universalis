import React from "react"

function Main() {
    return(
        <div className="main">
            <p className="main--intro">
                Welcome to Somber Item Finder. This section of the website searches for the lowest and
                highest price of any item in any data center using Universalis. First, choose the Data
                Center below and the corresponding World. Alternatively, you can leave the World section
                blank/empty in order to search the lowest and highest price of a specific item in your choice of
                Data Center (thanks to World travel).
            </p>
        </div>
    )
}

export default Main;