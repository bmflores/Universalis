import React from "react"

function Finder() {
    return(
        <div className="item">
            <input type="text" className="item--name" required>Enter item name here</input>
            <button>Search</button>
        </div>
    )    
}

export default Finder;