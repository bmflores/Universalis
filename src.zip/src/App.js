import logo from './logo.svg';
import Logo from './Components/Logo'
import Header from './Components/Header'
import Introduction from "./Components/Introduction"
import Finder from "./Components/Finder"

function App() {
  return (
    <div>
      <Logo />
      <Header />
      <Introduction />
    </div>
  );
}

export default App;
